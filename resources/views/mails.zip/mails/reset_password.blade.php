Dear Calenders,<br/>
Your New Password is {{$data['password']}}
